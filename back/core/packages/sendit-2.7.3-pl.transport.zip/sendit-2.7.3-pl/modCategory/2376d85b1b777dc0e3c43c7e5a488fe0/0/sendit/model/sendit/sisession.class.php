<?php
/**
 * @package sendit
 * @property string $session_id
 * @property string $class_name
 * @property string $data
 * @property datetime $createdon
 */
class siSession extends xPDOSimpleObject {}