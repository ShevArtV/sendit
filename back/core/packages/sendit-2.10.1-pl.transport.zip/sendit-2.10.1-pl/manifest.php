<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '2.10.1-pl
==============
- Токен SendIt (sitoken) больше не перевыпускается на каждой странице: он живёт si_token_ttl секунд
  (по умолчанию 900), после замены предыдущий ещё si_token_grace секунд (по умолчанию 60) принимается
  action.php. Исправляет «Невалидный токен.» у фоновых запросов, отправленных одновременно с загрузкой
  другой страницы или вкладки. Токен генерируется random_bytes, сравнивается hash_equals.
- Добавил системные настройки si_token_ttl и si_token_grace.

2.10.0-pl
==============
- Добавил вход и регистрацию по одноразовому коду (только MODX 2): сниппет siSendCode, валидатор
  siCheckCode, хук siCodeIdentification, пресеты code_send, code_send_register, code_auth,
  code_register, пример формы siExampleCodeAuthForm. Код хранится HMAC-хэшем под ключом получателя,
  а не сессии; лимиты codeTtl, codeResendDelay, codeAttempts, codeHourlyLimit, codeLength задаются
  в пресете. Телефон ищется по цифрам, без учёта маски в профиле.
- Доставку кода пакет не реализует: проект пишет класс с интерфейсом siCodeSender (SMS, Telegram,
  почта) и подключает его настройками si_code_sender, si_code_sender_path или параметрами пресета
  codeSender, codeSenderPath.
- Добавил события siOnBeforeSendCode (подменить код или запретить отправку) и siOnCodeLogin.
- Добавил сохранённую корзину покупателя (таблица si_user_carts, действие savecart): корзина
  сохраняется на событиях корзины miniShop2 и возвращается при входе с другого устройства;
  совпавшая позиция получает большее количество, а не сумму. Работает при ms2_tmp_storage=session.
- Добавил заявку на возврат из кабинета (действие return, пресет order_return): выбор позиций
  и количества, причина, комментарий. Настройки si_cabinet_return_statuses и
  si_cabinet_return_days. Что делать с заявкой, решает проект на siOnUserCabinetAction
  (method requestReturn).
- Параметр пресета reloadPage работает для любых пресетов, а не только кабинета.
- Добавил настройку si_cabinet_page_id — страница кабинета. Пресеты входа и регистрации (auth,
  sms_auth, sms_register, code_auth, code_register, afterLoginRedirectId в register) ведут на неё
  значением redirectTo = cabinet, менять пресеты под проект не нужно. По умолчанию 5, как было
  зашито в пресетах; 0 — без перехода. ID или URL в пресете по-прежнему важнее настройки.
- Чанки кабинета и примеры форм свёрстаны в стиле остальных примеров пакета.

2.9.0-pl
==============
- Добавил работу покупателя с заказами miniShop2 (только MODX 2): список заказов с составом
  (сниппет siUserOrders, render пресета user_orders с пагинацией), перенос позиций в корзину,
  повтор с переходом на страницу оформления, оплата существующего заказа через его способ
  оплаты, отмена. Пресеты order_tocart, order_repeat, order_pay, order_cancel.
- Добавил адреса доставки покупателя (таблица si_user_addresses, сниппет siUserAddresses):
  сохранение, удаление, адрес по умолчанию и быстрый выбор на странице оформления. Пресеты
  address_save, address_remove, address_default, address_apply. JS-модуль OrderFields
  заполняет форму #msOrder выбранным адресом.
- Выбранные в кабинете поля держатся в сессии SendIt и подставляются на msOnBeforeAddToOrder,
  пока покупатель не поправит поле сам; без выбора подставляется адрес по умолчанию.
- Набор действий кабинета настраивается в системных настройках: si_cabinet_actions,
  si_cabinet_checkout_id, si_cabinet_cancel_statuses, si_cabinet_pay_statuses.
- Добавил события siOnBeforeUserCabinetAction (поправить данные действия или запретить его)
  и siOnUserCabinetAction (после выполнения).
- Работа идёт через контракт miniShop2 (cart->add, order->add, changeOrderStatus,
  msPayment::send), без привязки к конкретным обработчикам корзины и заказа.

2.8.6-pl
==============
- SECURITY: известные SQLi-последовательности в полях SendIt отклоняются до запуска
  snippet-а; ответ формы не раскрывает правило срабатывания.
- SECURITY: прежняя «санитизация» молча вырезала слова и символы из легитимного текста,
  но не закрывала SQL-инъекции. Входные значения теперь сохраняются без SQL-экранирования;
  SQL-безопасность кода snippet-а обеспечивают только prepared statements.
- TESTS: добавлены автономные проверки нормализации и блокировки известных SQLi.

2.8.5-pl
==============
- FIX: Восстановление пароля через PasswordReset больше не сжигает ссылку до проверки
  срока действия и успешного сохранения пользователя. Повторный переход по ссылке в
  пределах TTL выставляет тот же временный пароль, поэтому предпросмотр письма или
  антивирус не ломает сброс для пользователя.
- FIX: Ручная смена пароля через update очищает временный пароль восстановления, чтобы
  старая ссылка не могла откатить пароль назад.
- FIX: Исправлен fallback срока действия ссылки восстановления при пустом activationUrlTime.
- DOCS: Добавлен пример вывода нового временного пароля на странице activationResourceId
  через результат некешируемого PasswordReset.

2.8.4-pl
==============
- Закрыл запись файла с произвольным именем и путём через публичный экшен uploadChunk:
  имя из заголовка X-CONTENT-NAME больше не подставляется в путь. Приём чанка разрешён
  только для файла, который прошёл serverside-валидацию (validate_files) в этой же сессии,
  с теми же расширением, размером и пресетом; все пути проверяются на принадлежность
  каталогу загрузок сессии до создания каталога и записи.
- Закрыл удаление произвольного файла через removeFile: путь проверялся вхождением
  session_id в строку, поэтому uploaded_files/{sid}/../../../core/config/config.inc.php
  проходил проверку. Теперь путь канонизируется и обязан остаться внутри каталога
  загрузок сессии. Флаг forceRemove для внутренних вызовов сохранён.
- Закрыл path traversal в attachFiles(): список файлов из POST подставлялся в путь
  без проверки.
- Добавил серверную нормализацию имён файлов (транслитерация без ext-intl, kebab-case,
  нижний регистр расширения, лимит длины) и обезвреживание исполняемых расширений:
  shell.php -> shell-php, shell.php.jpg -> shell-php.jpg.
- Добавил событие siOnSanitizeFileName: проект может задать свои правила именования
  вплоть до полного переименования файла и раскладки по подкаталогам. Параметры: name
  (оригинал), sanitized (имя по правилам пакета), extension, directory, context,
  formName, presetName, SendIt; ответ — returnedValues[\'name\'], пустой ответ означает
  "дефолт устраивает". Имя, вернувшееся из плагина, в любом случае проходит
  security-постфильтр пакета.
- validate_files возвращает карту data.names (исходное имя -> имя на сервере), клиентский
  загрузчик работает по ней. На сервер теперь уходит исходное имя файла, чтобы плагин
  проекта получал оригинал, а не результат клиентской транслитерации.
- Удаление файла, загрузка которого не завершилась, убирает каталог его чанков, а не
  каталог сессии целиком.

2.8.3-pl
==============
- Исправил PHP warning "Undefined array key onestepform" в SendIt::getExtends() —
  обращение к несуществующему пресету при extends теперь через `?? []`.
- Исправил PHP warning "Undefined array key siSession" в плагине sendit (OnHandleRequest) —
  чтение cookie заменено на `empty($_COOKIE[\'siSession\'])`.

2.8.2-pl
==============
- Логирование переведено на mxLogger (единственный приёмник). Добавлен класс siLogger
  (services/siLogger.class.php), делегирующий записи сервису mxLogger; если он не
  установлен — один раз предупреждает в журнале MODX и молчит.
- Новые настройки: si_debug (вкл/выкл, включено из коробки) + si_log_level (минимальный
  уровень debug|info|warning|error, по умолчанию error). Консистентно с mxlogger.min_level.
- Тэги: базовые sendit + forms, этапные auth / preset / session. Боевые вызовы $modx->log
  (пресеты, таблица сессий, авторизация) переведены в логгер с нужным уровнем; дамп
  логина/пароля при ошибке авторизации убран (теперь debug без значений полей).
- Скрипт modxbuilder/sendit/_mk_setting.php для создания настроек в БД стенда.

2.8.1-pl
==============
- Исправил блокировку модуля UserBehaviorTracker корпоративными прокси/DLP по имени файла (ошибка 499): модуль переименован в SessionLogger, cookie `siubt` → `sisl`.
- Убрал re-throw в Main._initModule — при падении любого модуля приложение продолжает инициализацию (graceful fallback), ошибка только логируется в console.error.

2.8.0-pl
==============
- Добавил защиту Proof of Work (PoW) — клиент решает криптографическую задачу перед отправкой, что делает спам экономически невыгодным.
- Добавил шифрованную подпись поведения (Encrypted Behavioral Signature) — результат анализа UserBehaviorTracker шифруется AES-128-GCM и проверяется на сервере.
- Добавил отслеживание времени заполнения формы (formFillTime) — защита от мгновенной отправки ботами.
- Добавил параметры пресетов: usePoW, powDifficulty, useBehaviorSign, minFillTime, maxBotScore.
- Добавил per-preset карту защиты (protectionMap) — клиент применяет защиту только для тех форм, где она включена в пресете.
- Добавил ротацию challenge и ключа шифрования после каждой успешной отправки (one-time use).
- Добавил JS модули ProofOfWork и BehaviorSign.

2.7.3-pl
==============
- Вернул в конфиг QuizForm параметр nosaveAttr.
- Добавил проверку на тип значения перед вставкой сохраненных данных.
- Добавил загрузку скриптов в админке

2.7.2-pl
==============
- Добавил событие JS \'si:send:reset:after\', которое срабатывает после сброса формы.
- Исправил ошибку удаления загруженных файлов.

2.7.1-pl
==============
- Сделал обязательным указание пресета, даже дефолтного, чтобы предотвратить ненужные отправки
- Изменил порядок сохранения данных из чекбоксов и переключателей.

2.7.0-pl
==============
- Переработал невидимую капчу.
- Добавил возможность использовать кастомный session_id вместо стандартного.

2.6.0-pl
==============
- Добавил класс UserBehaviorTracker для анализа поведения пользователя.

2.5.0-pl
==============
- Поменял порядок проверки на Email.
- Добавил системное событие senditOnSetValue.

2.4.9-pl
==============
- Доработал добавление HTML в блоки.

2.4.8-pl
==============
- Исключил из проверки на SQL-инъекции email.

2.4.7-pl
==============
- Исправил ошибку вызова метода loadScript().
- Добавил возможность запоминать пользователя при авторизации без пароля.
- Добавил дополнительную санитизацию входящих данных для защиты от SQL инъекций.

2.4.6-pl
==============
- Сделал метод getWebConfig() публичным.

2.4.5-pl
==============
- Добавил селектор пресета в конфиг.

2.4.4-pl
==============
- Вынес инициализацию события \'si:init\' в индексный файл.

2.4.3-pl
==============
- Сделал webConfig public.

2.4.2-pl
==============
- Исправил определение версии скриптов.
- Переписал инициализацию с учётом того, что метод getInstance() возвращает промис.

2.4.1-pl
==============
- Сделал так чтобы метод getInstance дожидался полной инициализации перед возвращением экземпляра.

2.4.0-pl
==============
!!! ОБНОВЛЯЙТЕСЬ С ОСТОРОЖНОСТЬЮ. ЕСЛИ ИСПОЛЬЗОВАЛИ КАСТОМНЫЙ КОНФИГ, ПЕРЕПИШИТЕ ЕГО В СООТВЕТСТВИИ С НОВВОЙ ВЕРСИЕЙ !!!
- Немного переписал JS, чтобы модули подключались только если на странице есть хотя бы один элемент с селектором из поля конфигурации модуля rootSelector.
- Метод Sending.prepareSendParams() заменён на метод Sending.sendRequest(), при этом обратная совместимость сохранена.
- Метод Sending.send() заменён на метод Sending.fetch(), при этом обратная совместимость сохранена.
- Добавил версионирование скриптов.
- Добавил событие senditOnGetWebConfig для возможности прокидывать свои и изменять стандартные параметры веб конфига

2.3.1-pl
==============
- Добавил сброс ответа от сервера в JS.

2.3.0-pl
==============
- Обновил iziToast до 1.5.0
- Добавил событие JS \'si:notify:before\', которое позволяет задать опции показа уведомлений.
- Поместил ответ сервера в свойство объекта Sending, теперь ответ сервера доступен где угодно так SendIt.Sending.result
- Исправил ошибку автологина сразу после регистрации.

2.2.5-pl
==============
- Добавил возможность динамически выводить общее количество результатов указав в вёрстке блок с атрибутом [data-pn-total-results="presetName"]
- Добавил возможность указывать ключи лексиконов для передачи сообщений и имён полей. Для этого нужно в параметрах сниппета указать ключ useLexicons
в значении нужно перечислить через запятую пространства имён и темы для загрузки лексиконов в формате namespace:topic

2.2.4-pl
==============
- Исправил ошибку при которой уже загруженный файл добавлялся в список даже если общее количество при этом превышает допустимое.

2.2.3-pl
==============
- Правки предупреждений в PHP 8.
- Добавил возможность передавать в качестве значения в поле из параметра userGroupsField строку с разделителем \'запятая\'


2.2.2-pl
==============
- Для облегчения перехода с AjaxForm сделал параметр form синонимом параметра tpl.

2.2.1-pl
==============
- Исправил ошибку совместимости с ClientConfig в MODX 3.*
- Если вы используете ClientConfig нужно добавить задачу в крон, которая запустит скрипт core/components/sendit/cron/run.php

2.2.0-pl
==============
- Добавил возможность генерации username при регистрации, для этого нужно не указывать в пресете параметр usernameField.
- Добавил возможность авторизовать пользователя по любому полю, кроме extended. Поле должно содержать уникальное для конкретного пользователя значение.

2.1.7-pl
==============
- Небольшие правки в JS.

2.1.6-pl
==============
- Добавил в событие \'si:send:before\' параметр submitter, который содержит элемент, который стал инициатором отправки.
- Устранил критическую уязвимость при загрузке файлов.

2.1.5-pl
==============
- Добавил очистку блока вставки контента, если контента нет.
- Добавил принудительную смену метода вставки если всего одна страница в пагинации.
- Исправил условие получения корневого элемента(формы) в JS.
- Добавил системное событие OnBeforeFileRemove и параметр forceRemove в класс SendIt для удаления файлов без проверки владельца.
- Добавил параметры в событие sf:change
- Добавил событие si:quiz:init
- Добавил метод resetHandler() в модуль загрузки файлов.

2.1.4-pl
==============
- Исправил ошибку "Укажите почту получателя".

2.1.3-pl
==============
- Теперь на событие OnBeforeReturnResponse можно полностью менять возвращаемые на фронт данные.

2.1.2-pl
==============
- Исправил ошибку валидации для имён файлов содержащих больше одной точки в названии.

2.1.1-pl
==============
- Переименовал сниппет ResetPassword в PasswordReset, чтобы не было конфликтов со сниппетом компонента Login.

2.1.0-pl
==============
- Добавил возможность выводить пагинацию списком.

2.0.7-pl
==============
- Исправил фатальную ошибку определения $allowDirs.

2.0.6-pl
==============
- Добавил сниппет mx3RenderForm.
- Адаптировал код под Modx 3.
- Убрал возможность удалять папки с фронта.
- Добавил системную настройку si_allow_dirs для указания разрешённых путей для удаления папок.

2.0.5-pl
==============
- Поправил ошибку в методе forgot().

2.0.4-pl
==============
- Поправил ошибку при которой не устанавливался класс ошибки при отправке данные на события change и input.
- Добавил пресет simpleform.

2.0.3-pl
==============
- Заменил константы путей на опции.

2.0.2-pl
==============
- Поправил ошибку обзёрвера в JS.
- Добавил в сниппет ResetPassword параметр toPls.

2.0.1-pl
==============
Общее
- Добавил проверку параметра  antispam.
- Добавил возврат ответа из сниппета ResetPassword.
- Изменились параметры события OnBeforeFileValidate.

2.0.0-pl
==============
Общее
- Переместил основные классы в папку services.
- Поправил пути по умолчанию в методе loadCssJs().
- Избавился от использования сессий.
- Убрал проверку частоты и количества отправок для форм не использующих хук Email или FormItAutoResponder.
- Добавил параметры pauseBetweenSending и sendingPerSession для управления проверкой отправки на спам.
- Добавил в параметры события \'OnGetFormParams\' объект SendIt, теперь можно создавать много плагинов на это событие.
- Убрал параметр event из метода prepareSendParams().
- Поменял порядок параметров в методе prepareSendParams().
- Переписал метод getExtends() так, чтобы он мог работать с другими файлами пресетов.
- Добавил возможность автоматической вставки контента, для этого сниппет должен возвращать параметр html, а в пресете нужно указать параметры resultBlockSelector и resultShowMethod


Загрузка файлов
- Добавил проверку на конечный слэш в методе removeDir() класса SendIt.
- Добавил в плагин удаление загруженных файлов, срок хранения которых истёк.
- Добавил системную настройку регулирующую срок хранения загруженных файлов si_storage_time.
- Переписал отправку файлов, чтобы работала многопоточность.
- Добавил очередь загрузки, если загрузка не началась - файл можно удалить из очереди кликом по полоске прогресса.
- В процессе загрузки одного файла, можно добавлять другие файлы в очередь.
- Загруженные файлы после перезагрузки страницы не удаляются, это позволяет продолжить загрузку, если она была прервана.
- Добавил системную настройку регулирующую точность округления процентов при показе прогресса загрузки файлов si_precision.
- Добавил параметр loadedUnit для пресета загрузки файлов, который позволяет указывать в каких единицах измерения показывать прогресс загрузки.
- Добавил передачу параметра nomsg для обозначения автоматического удаления файла при очистке полей.

Квизы
- Добавил в квиз JS событие \'si:quiz:progress\'.
- Добавил возможность убирать не нужные кнопки в квизе.

Идентификация
- Переписал метод forgot, теперь сброс пароля надо подтверждать.
- Добавил сниппет ResetPassword, который нужно вызывать для смены пароля.
- Добавил сниппет userExists для проверки существования пользователя.
- Есть два JS события ДО и ПОСЛЕ внесения изменений на страницу, и есть одно серверное событие для изменения параметров.

Пагинация
- Добавил возможность вызывать любые сниппеты с постраничной навигацией.
- Можно выводить на странице несколько блоков с пагинацией.
- Можно динамически менять параметры вывода и выводить результаты с пагинацией.
- Есть классическая пагинация, кнопкой или по скроллу.

1.2.6-pl
==============
- Исправил ошибку неопределенного конфига в обработчике загрузки файлов.
- Добавил удаление класса disabled у кнопки назад.

1.2.5-pl
==============
- Добавил минимально необходимые стили.

1.2.4-pl
==============
- Поправил метод удаления файлов и директорий.
- Удалил лишний параметр из JS метода квиза changeItem().
- Поправил ошибку в загрузчике файлов при отсутствии в ответе параметра data.
- Добавил в ответ сервера параметры вызова кастомного сниппета.
- Добавил в квиз событие \'si:quiz:reset\'.
- Добавил в стандартный чанк письма вывод квиза.
- Исправил ошибку обработки множества полей загрузки при отправки формы.
- Добавил в JS метод getRoot()
- Добавил в JS метод addInstances() в FileUploaderFactory
- Добавил в FileUploader событие \'fu:preview:remove\'
- Добавил системное событие OnBeforeReturnResponse

1.2.3-pl
==============
- Оставил проверку на спам только в action.php

1.2.3-pl
==============
- Добавил возможность передавать параметры в метод prepareSendParams.
- Добавил возврат результата запроса для возможности писать JS API.

1.2.2-pl
==============
- Убрал из возвращаемых на фронт данных объект класса SendIt.
- Заменил событие OnHandLeRequest на OnWebPageInit это решило проблему с частой ошибкой "Невалидный токен".

1.2.1-pl
==============
- Добавил пример обращения к файловому сниппету.
- Заменил обращение к методу $modx->runSnippet() на кастомный метод в основном классе.

1.2.0-pl
==============
- Добавил возможность через системные настройки задавать список не нужных в ответе сервера параметров.
- Поправил ошибку вывода псевдонимов полей в чанке письма.
- Добавил возможность передавать параметры валидации файлов из JS.
- Добавил событие OnBeforeFileValidate, которое позволяет изменить параметры валидации.
- Добавил параметр isTrusted для события \'si:quiz:change\', позволяет отличить автопереключение от переключения пользователем.
- Добавил обработку атрибута data-si-nosave в много шаговой форме, чтобы отключить переключение на последний шаг при загрузке страницы.
- Добавил возможность загружать файлы перетаскиванием.
- Исправил ошибку мигающего показателя прогресса в квизе.
- Исправил ошибку обработчика ответа в опроснике при отсутствии пагинации в квизе.
- Добавил обработку множества полей добавления файлов внутри одной формы.
- Добавил обработку параметра validate, чтобы убрать переносы строк.
- Изменил проверку куки в плагине, что убрать предупреждение.
- Изменил проверку ключей в основном классе.
- Добавил возможность автоматической авторизации после активации пользователя и переадресации на нужный ресурс по ID

1.1.2-pl
==============
- Поместил токен в сессию. Добавил проверку на наличие токена в сессии.
- Создал сниппет RenderForm для любителей классических вызовов.

1.1.1-pl
==============
- Убрал стили по умолчанию
- Убрал двойную отправку формы при нажатии на Enter
- Поправил условия отправки по клику

1.1.0-pl
==============
- Добавил атрибут data-si-nosave для форм, которые не нужно сохранять
- Добавил возможность отправить форму по клику на произвольный элемент внутри неё

1.0.9-pl
==============
- Исправил ошибку обработки формы без отправки целей
- Добавил транслитерацию кириллицы в именах загружаемых файлах

1.0.8-pl
==============
- Изменил способ передачи параметров и заголовков в событие si:send:before
- Исправил ошибку поиска формы в обработчике файлов
- Добавил имя пресета в серверное событие OnGetFormParams
- Добавил доступ к кнопкам в событии si:quiz:change
- Удалил глобальные стили
- Исправил невозможность указывать путь к кастомному коннектору

1.0.7-pl
==============
- Исправил баг создания папки для загрузки файлов.

1.0.6-pl
==============
- Добавил возможность указывать цели для метрики в коде шаблона в атрибуте data-si-goal.
- Для одного элемента можно указывать несколько целей через запятую.
- Цели указанные в вызове будут добавлены к указанным в шаблоне.


1.0.5-pl
==============
- Исправил баг с ошибкой передачи имени события
- Сделал метод Identification::generateCode($modx) статичным
- Переработал обработку ошибок, теперь их можно увидеть все, если есть текст

1.0.4-pl
==============
- Добавил возможность отправлять данные на сервер без формы
- Добавил рекурсивное наследование


1.0.3-pl
==============
- Добавил ограничение общее количество отправок одной формы без перезагрезки страницы и ограничение на периодичность отправок
- Удалил вывод логов в sending.js
- Добавил возможность использовать параметры по умолчанию во всех формах.
- Убрал обязательную очистку полей формы квиза
- Изменил пути к стилям и скриптам на стандартные.
- Добавил событие OnCheckPossibilityWork для возможности отменить ограничение на количество отправок для отдельных форм.

1.0.2-pl
==============
- Путь к пресетам указывается теперь относительно папки core
- Добавил вывод сообщения из параметра vallidationErrorMessage
- Исправлена ошибка отправки целой формы на события change и input.
- Исправлена ошибка плагина из-за неверного пути к пресетам при вынесенной на уровень выше папке core.
- Исправлена ошибка вызова функции удаления папки с загруженными файлами.

1.0.1-pl
==============
- В модуле SaveFormData добавил события si:set:before, si:set:after, si:change.
- Исправил мелкие ошибки.
- В основном классе поправил процесс формирования поля fields в массиве $_POST.


1.0.0-pl
==============
- Первая стабильная сборка.

1.0.0-beta
==============
- Первая сборка.
',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
SendIt
--------------------
Author: Shevchenko Artur <shev.art.v@yandex.ru>
--------------------

SendIt - компонент для работы с формами на сайте.

!!!ВАЖНО!!! При установке компонент так же будут установлены pdoTools и FormIt.

Возможности:
1. Отправка данных полей форм на сайт без перезагрузки страницы.
2. Загрузка файлов любых размеров на сервер и прикрепление их к письмам.
3. Создание опросников (многошаговых форм)
4. Сохранение данных форм в localStorage и заполнение полей после перезагрузки.
5. Есть авторизация, регистрация, восстановление пароля и редактирование личных данных.

Особенности:
1. Использует cookie и localStorage.
2. Не требует вызова сниппетов для отправки формы.
3. Есть защита от ботов и внешнего доступа.
4. Можно корректировать работу с помощью событий.
5. Отправка возможна на события change и input.

--------------------
SQL-инъекции
--------------------
SendIt отклоняет известные SQLi-последовательности до вызова snippet-а и возвращает
обычную ошибку формы. Это дополнительный барьер, а не способ безопасно подставлять
значения в SQL.

Значения полей не экранируются для SQL и не должны передаваться в raw SQL. Snippet,
который читает $_POST, обязан использовать xPDO criteria или подготовленные выражения
с bind-параметрами. Не фильтруйте SQL-токены вырезанием: это портит легитимный текст и
не закрывает другие варианты инъекции.

--------------------
Восстановление пароля
--------------------
Пресет forgot отправляет пользователю ссылку подтверждения. Новый временный пароль
применяется на странице activationResourceId сниппетом PasswordReset по параметру ?rp=.

Сниппет должен быть вызван некешируемо. Если на странице нужно показать новый пароль,
сохраните результат сниппета в переменную и выведите temp_password из extended:

{set $resetResult = \'!PasswordReset\' | snippet: []}
{if $resetResult}
    <p>Пароль изменён.</p>
    {if $resetResult.extended.temp_password}
        <p>Новый пароль: <strong>{$resetResult.extended.temp_password}</strong></p>
    {/if}
{/if}

Временный пароль хранится в профиле до истечения срока ссылки. Повторный переход по
ссылке в пределах этого срока выставляет тот же пароль.

--------------------
Событие siOnSanitizeFileName
--------------------
Позволяет проекту задать свои правила именования загружаемых файлов вплоть до полного
переименования, не патча код пакета.

Когда вызывается: на этапе validate_files, до начала приёма чанков — то есть до того,
как файл окажется на диске.

Параметры:
  name        - имя файла, как его прислал браузер (оригинал, без изменений);
  sanitized   - имя по правилам пакета: транслитерация, kebab-case, нижний регистр
                расширения, обезвреженные исполняемые расширения;
  extension   - расширение из sanitized;
  directory   - каталог загрузок текущей сессии;
  context     - upload;
  formName    - имя формы;
  presetName  - имя пресета;
  SendIt      - экземпляр класса.

Ответ: $modx->event->returnedValues[\'name\']. Пустой ответ означает "имя по умолчанию
устраивает". Можно вернуть имя с относительным подкаталогом, например docs/2026/file.pdf.

Гарантии: имя, вернувшееся из плагина, в любом случае проходит security-постфильтр
пакета — срез пути наружу и ../, управляющих символов, схлопывание точек, лимит длины,
обезвреживание исполняемых расширений. Файл всегда остаётся внутри каталога загрузок
текущей сессии. Плагин может звать SendIt::sanitizeFileName() из своего обработчика:
повторного вызова события не будет.

Пример:
  switch ($modx->event->name) {
      case \'siOnSanitizeFileName\':
          $modx->event->returnedValues[\'name\'] = date(\'Ymd\') . \'-\' . $sanitized;
          break;
  }

--------------------
GitHub: https://github.com/ShevArtV/sendit
',
    'setup-options' => 'sendit-2.10.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '297deedc08eadabc3de4fbdba0df57fc',
      'native_key' => 'sendit',
      'filename' => 'modNamespace/a623721c3ffdce8126dcbeffeec3c107.vehicle',
      'namespace' => 'sendit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '98ef1cfa0113c89dfe507a30b05bf852',
      'native_key' => NULL,
      'filename' => 'modCategory/e80fef489efea71d7e0da975061a770d.vehicle',
      'namespace' => 'sendit',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0820c85b8ee348eedc8778c9e951bf9b',
      'native_key' => NULL,
      'filename' => 'modCategory/188e080e7633ba1557957cb6bfd48225.vehicle',
      'namespace' => 'sendit',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b236b9e8bcd64582c01d15c753e195b',
      'native_key' => 'si_allow_dirs',
      'filename' => 'modSystemSetting/2f64400fabfff38da4388b87652d0288.vehicle',
      'namespace' => 'sendit',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46d00226f310266ab16e0727cee1c7f7',
      'native_key' => 'si_cabinet_actions',
      'filename' => 'modSystemSetting/476e5f7b85c4d0614d0b80b9f8783430.vehicle',
      'namespace' => 'sendit',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63e1a0e9878594bdec31cedf9bb05edc',
      'native_key' => 'si_cabinet_cancel_statuses',
      'filename' => 'modSystemSetting/0781df8074a446b7d81786e89af7d9d7.vehicle',
      'namespace' => 'sendit',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '933623e65b54901bb7c33072325c0523',
      'native_key' => 'si_cabinet_checkout_id',
      'filename' => 'modSystemSetting/0951bf2737f2644a140138c201cf47f6.vehicle',
      'namespace' => 'sendit',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37cb1de329fe8bc1544713498d1769f8',
      'native_key' => 'si_cabinet_page_id',
      'filename' => 'modSystemSetting/bd1774878e4d6787a46a1d54789355e0.vehicle',
      'namespace' => 'sendit',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f68eae13e2bfb643388a483134f2810d',
      'native_key' => 'si_cabinet_pay_statuses',
      'filename' => 'modSystemSetting/c7d2a9acf15fd3b9f550554ad4ff1a82.vehicle',
      'namespace' => 'sendit',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9867e1d9241dc348c877504dc83909a5',
      'native_key' => 'si_cabinet_return_days',
      'filename' => 'modSystemSetting/0d5f1ecb9f6e76e7b76478211ca2b132.vehicle',
      'namespace' => 'sendit',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b00d84642ce69ae2d739b43a8c0f54c',
      'native_key' => 'si_cabinet_return_statuses',
      'filename' => 'modSystemSetting/e90bd622e3852225001b21370471f07e.vehicle',
      'namespace' => 'sendit',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd025dff36ac7fae4a0aaeb22e7cdb751',
      'native_key' => 'si_code_sender',
      'filename' => 'modSystemSetting/ec87be28871868cb168887338a7d0753.vehicle',
      'namespace' => 'sendit',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c46786afe87ca63df47264e1925f3926',
      'native_key' => 'si_code_sender_path',
      'filename' => 'modSystemSetting/5ac6b83be311b35f40fdb94c5ee88c36.vehicle',
      'namespace' => 'sendit',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9957dc0dd53711028173ab2b94c66dc9',
      'native_key' => 'si_counter_id',
      'filename' => 'modSystemSetting/17670e58f1863cb0ee84b606bdb51377.vehicle',
      'namespace' => 'sendit',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60f6e58f9b9c56bd2bed5ae153a65b02',
      'native_key' => 'si_debug',
      'filename' => 'modSystemSetting/507061b5aa234b4734c9ee91810bfd54.vehicle',
      'namespace' => 'sendit',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c905afd3a91b69591b062f80a4aa3cb8',
      'native_key' => 'si_default_admin',
      'filename' => 'modSystemSetting/e94c0b7f0c49f642665a3ef44e2b3cdb.vehicle',
      'namespace' => 'sendit',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f49bb90a40a79b3a603280311952243',
      'native_key' => 'si_default_email',
      'filename' => 'modSystemSetting/a44bb2a9f5eef65c6972cd10b899fe42.vehicle',
      'namespace' => 'sendit',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6f7f65c9edf66d4e9f50a9ff53a8a4e',
      'native_key' => 'si_default_emailtpl',
      'filename' => 'modSystemSetting/ecfdaa4744c78358a3abfce7671fd0f6.vehicle',
      'namespace' => 'sendit',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf35491553452e7488d2561f9cde5761',
      'native_key' => 'si_frontend_css',
      'filename' => 'modSystemSetting/6f2bf747b0f9ab07ecf22d1f31e2c5b7.vehicle',
      'namespace' => 'sendit',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dfbc94b5f11bad13a610e2d179e39e9',
      'native_key' => 'si_frontend_js',
      'filename' => 'modSystemSetting/c975edb61cb1b3686d954b7ae680e5b5.vehicle',
      'namespace' => 'sendit',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79a215f6b80852ff27e206320e2e1e17',
      'native_key' => 'si_js_config_path',
      'filename' => 'modSystemSetting/92517ea6af7c71d64bfef9ebeaf88e63.vehicle',
      'namespace' => 'sendit',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60cd30ace2f10a1e43e3bd7274e476f0',
      'native_key' => 'si_log_level',
      'filename' => 'modSystemSetting/c7adbc8e2ee8c99e1c4919bc2b56749c.vehicle',
      'namespace' => 'sendit',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eac660d3eb67b4e15d5d4a543420d17d',
      'native_key' => 'si_max_sending_per_session',
      'filename' => 'modSystemSetting/dc443db75083f29f2ac428851927e621.vehicle',
      'namespace' => 'sendit',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ccd3fd21b5e1655a4fc83025f2390c3',
      'native_key' => 'si_path_to_presets',
      'filename' => 'modSystemSetting/25d50bbcac172f01c9eebadace4fe10d.vehicle',
      'namespace' => 'sendit',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b524849fbbd2211242236498b404f7b4',
      'native_key' => 'si_pause_between_sending',
      'filename' => 'modSystemSetting/fa6c4828d7504d401aecf4f0ead8c81b.vehicle',
      'namespace' => 'sendit',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cf9f5cb06e9cae86e9c96318bbba3db',
      'native_key' => 'si_precision',
      'filename' => 'modSystemSetting/0d842730b7e5bf3a8e7acc7b2ddaa585.vehicle',
      'namespace' => 'sendit',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aeffa06c0892ec628b5bf3a1b1267892',
      'native_key' => 'si_send_goal',
      'filename' => 'modSystemSetting/69fa39e67569cfcd72773a1b3e562f80.vehicle',
      'namespace' => 'sendit',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4216e9b06f33c9f0c34bd89ebaf083e7',
      'native_key' => 'si_storage_time',
      'filename' => 'modSystemSetting/a7236d3f6ab44c2aa8be38cd1da65d20.vehicle',
      'namespace' => 'sendit',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '147e2cf9f8219668812c156e283b9a43',
      'native_key' => 'si_token_grace',
      'filename' => 'modSystemSetting/897b5d30deeb9cb020ca8718bfde660b.vehicle',
      'namespace' => 'sendit',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5915075a3f7bd1e46f0e4e55be88738b',
      'native_key' => 'si_token_ttl',
      'filename' => 'modSystemSetting/71a336ad54a4b9d268e6f7806f07cbd6.vehicle',
      'namespace' => 'sendit',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f36d5426916d7f1f7bddf3733ff1aec3',
      'native_key' => 'si_unset_params',
      'filename' => 'modSystemSetting/957067d2541502f5255035874d355117.vehicle',
      'namespace' => 'sendit',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '075994e273bd3ce360bcb1b178a49e69',
      'native_key' => 'si_uploaddir',
      'filename' => 'modSystemSetting/b17a48769fbfe6039f5c0ae6b04b8c19.vehicle',
      'namespace' => 'sendit',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f44451cfdc733ad5d4ed657ac2720a12',
      'native_key' => 'si_use_custom_session_id',
      'filename' => 'modSystemSetting/1c532e16b3443b9e9413bfa2c52914c7.vehicle',
      'namespace' => 'sendit',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1aafd8c51f0ee9f5421f75c37712c4bd',
      'native_key' => 'OnBeforeFileRemove',
      'filename' => 'modEvent/af5f28f253202ccce3d5f801636bf923.vehicle',
      'namespace' => 'sendit',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cf39e45666909b8f9437b7475a39269',
      'native_key' => 'OnBeforeFileValidate',
      'filename' => 'modEvent/269a44238a8c4fffd9f1ae64b69eb1bf.vehicle',
      'namespace' => 'sendit',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78efc36f59f711b983277d35aa816d16',
      'native_key' => 'OnBeforePageRender',
      'filename' => 'modEvent/235d96809b66c70a2fbcef05a49c1d43.vehicle',
      'namespace' => 'sendit',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99c0e6fe4346bb3f96c74ceeb614b7cf',
      'native_key' => 'OnBeforeReturnResponse',
      'filename' => 'modEvent/a8751f30eb54e04185135c12b78be8dd.vehicle',
      'namespace' => 'sendit',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df97c2974dc562e75846ebc41098f30c',
      'native_key' => 'OnCheckPossibilityWork',
      'filename' => 'modEvent/7155ff816d5a779b74d35b2f38802b54.vehicle',
      'namespace' => 'sendit',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe9fc09df1a3cc3571634a7f5794040d',
      'native_key' => 'OnGetFormParams',
      'filename' => 'modEvent/3ffd76fad1078833787343394daf54d3.vehicle',
      'namespace' => 'sendit',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8904e215323f60f833abc7e370581d1b',
      'native_key' => 'senditOnGetWebConfig',
      'filename' => 'modEvent/5f5272fcc5c5d9f25313e309ba98bb29.vehicle',
      'namespace' => 'sendit',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9abb34133cdcdb397d5b258c30215aa',
      'native_key' => 'senditOnSetValue',
      'filename' => 'modEvent/ffab7f41e695991dda327b7240ad7da5.vehicle',
      'namespace' => 'sendit',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89ff13129254b322a2a72be39f79a20c',
      'native_key' => 'siOnBeforeSendCode',
      'filename' => 'modEvent/1a1222e5367a4ed0947c9cfaed3018dd.vehicle',
      'namespace' => 'sendit',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ebd39d5bab7e3e59e58ab7e0201d6ed',
      'native_key' => 'siOnBeforeUserCabinetAction',
      'filename' => 'modEvent/0f9e69cabcc2b6037083d28f782d58c0.vehicle',
      'namespace' => 'sendit',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '563a92e2331e49e70f3c2c64d29cab05',
      'native_key' => 'siOnCodeLogin',
      'filename' => 'modEvent/e949772c6367bea620511d9c73424935.vehicle',
      'namespace' => 'sendit',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd48a02bd1673e264bd6cd6c54c25cc4e',
      'native_key' => 'siOnSanitizeFileName',
      'filename' => 'modEvent/5596b19153b298e425f7166eb0f5e876.vehicle',
      'namespace' => 'sendit',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6574690b7fa88924592a037cdd343fe8',
      'native_key' => 'siOnUserCabinetAction',
      'filename' => 'modEvent/37ffb8ac8a1ca8529d58bcd8d3270735.vehicle',
      'namespace' => 'sendit',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8689f37d3bf87c8a2ae95599eb857dea',
      'native_key' => 'siOnUserUpdate',
      'filename' => 'modEvent/3b079c0f9a2c2fa350eb7b5784d0f1a8.vehicle',
      'namespace' => 'sendit',
    ),
  ),
);