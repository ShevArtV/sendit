<?php
require_once (dirname(__DIR__) . '/sisession.class.php');
class siSession_mysql extends siSession {}