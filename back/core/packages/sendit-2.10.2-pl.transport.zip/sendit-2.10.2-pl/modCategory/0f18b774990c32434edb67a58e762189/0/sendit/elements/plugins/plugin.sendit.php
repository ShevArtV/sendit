<?php

/**
 * @var \modX $modx
 */
$corePath = $modx->getOption('core_path', null, MODX_CORE_PATH);
require_once $corePath . 'components/sendit/services/sendit.class.php';

switch ($modx->event->name) {
    case 'OnHandleRequest':
        if(empty($_COOKIE['siSession'])){
            $_COOKIE['siSession'] = SendIt::getSessionId($modx);
            $expires = time() + $modx->getOption('si_storage_time', '', 86400);
            setcookie('siSession', $_COOKIE['siSession'], $expires, '/', '', false, true);
        }
        break;
    case 'OnMODXInit':
        SendIt::clearSession($modx);
        break;
    case 'OnManagerPageInit':
    case 'OnWebPageInit':
        $alias = !empty($_REQUEST['q']) ? explode('.', basename($_REQUEST['q'])) : [];
        if (isset($alias[1]) && $alias[1] !== 'html') {
            return;
        }

        $modx->lexicon->load('sendit:default');
        $jsConfigPath = $modx->getOption('si_js_config_path', '', './sendit.inc.js');
        $cookies = !empty($_COOKIE['SendIt']) ? json_decode($_COOKIE['SendIt'], 1) : [];

        $powChallenge = bin2hex(random_bytes(16));
        $behaviorKey = bin2hex(random_bytes(16));
        // Токен живёт si_token_ttl, а не одну страницу: новый на каждой странице ломал фоновые
        // запросы, отправленные одновременно с другой загрузкой страницы той же сессии.
        require_once $corePath . 'components/sendit/services/sitokenttl.class.php';
        $token = SiTokenTtl::issue($modx, SendIt::getSession($modx));

        $data = [
            'simsgantispam' => $modx->lexicon('si_msg_trusted_err'),
            'sitoken' => $token['sitoken'],
            'sitrusted' => '0',
            'sijsconfigpath' => $jsConfigPath,
            'sipowchallenge' => $powChallenge,
            'sibehaviorkey' => $behaviorKey,
        ];
        SendIt::setSession($modx, array_merge($token, [
            'sendingLimits' => [],
            'powChallenge' => $powChallenge,
            'powTimestamp' => time(),
            'behaviorKey' => $behaviorKey,
        ]));

        $data = array_merge($cookies, $data);
        setcookie('SendIt', json_encode($data), 0, '/');

        break;
    case 'OnLoadWebDocument':
        $SendIt = new SendIt($modx);
        $SendIt->loadCssJs();
        break;
    case 'msOnBeforeAddToOrder':
        require_once $corePath . 'components/sendit/services/minishop/orderfields.class.php';
        $cabinetValue = siOrderFields::onBeforeAddToOrder($modx, (string)$key, $value);
        if ($cabinetValue !== null) {
            $modx->event->returnedValues['value'] = $cabinetValue;
        }
        break;
    case 'msOnCreateOrder':
        require_once $corePath . 'components/sendit/services/minishop/orderfields.class.php';
        require_once $corePath . 'components/sendit/services/minishop/savedcart.class.php';
        siOrderFields::clear($modx);
        siSavedCart::clear($modx, is_object($msOrder ?? null) ? (int)$msOrder->get('user_id') : 0);
        break;
    case 'msOnAddToCart':
    case 'msOnChangeInCart':
    case 'msOnRemoveFromCart':
    case 'msOnEmptyCart':
        require_once $corePath . 'components/sendit/services/minishop/savedcart.class.php';
        siSavedCart::save($modx, $cart ?? null);
        break;
    case 'OnWebLogin':
        require_once $corePath . 'components/sendit/services/minishop/savedcart.class.php';
        siSavedCart::restore($modx, $user ?? null);
        break;
}
